using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
     public int maxHealth = 100;  // Salud máxima del jugador.
    public int currentHealth;
    

    void Start()
    {
        // Inicializa la salud actual del jugador con la salud máxima.
        currentHealth = maxHealth;
    }
     public void Heal(int amount)
    {
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        Debug.Log("Curado. Salud actual: " + currentHealth);
    }

    // Función para recibir daño.
    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        Debug.Log("Jugador recibe daño: " + damage + ". Salud restante: " + currentHealth);

        // Verifica si la salud ha llegado a 0 o menos.
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    // Función para manejar la muerte del jugador.
    void Die()
    {
        Debug.Log("Jugador ha muerto.");
        // Aquí puedes implementar lógica adicional como reiniciar el nivel o mostrar una pantalla de muerte.
    }
     void RestartGame()
    {
        // Recarga la escena actual.
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
