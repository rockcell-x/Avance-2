using UnityEngine;

public class HealingItem : MonoBehaviour
{
     public int healingAmount = 20; // Cantidad que curará

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // Intentamos acceder al script de salud del jugador
            PlayerHealth health = other.GetComponent<PlayerHealth>();

            if (health != null)
            {
                health.Heal(healingAmount); // Curamos al jugador
            }

            Destroy(gameObject); // Eliminamos el objeto de curación
        }
    }
}
